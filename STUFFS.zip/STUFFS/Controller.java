import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Controller {
    private javax.swing.Timer animationTimer;
    private MainMenu mainMenu = new MainMenu();
    private Maze mazeView = new Maze();
    private GUI gui;

    private MazeLoader mzLoader;
    private MazeGrid mzGrid;

    public Controller() {
        this.gui = new GUI(mainMenu, mazeView);

        this.mainMenu.addMenuListener(new MenuListener());
        this.mazeView.addMazeListener(new MazeListener());

        mzLoader = new MazeLoader();
    }

    class MenuListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            switch (e.getActionCommand()) {
                case "START":
                    System.out.println("START BUTTON clicked");
                    gui.showMaze(mzGrid);
                    mazeView.loadMap(mzGrid); // you'll need this call too, see note below
                    mazeView.repaint();

                    break;
                case "LOAD":
                    System.out.println("LOAD BUTTON clicked");
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setFileFilter(new FileNameExtensionFilter(".txt", "txt"));
                    int response = fileChooser.showOpenDialog(null);

                    if (response == JFileChooser.APPROVE_OPTION) {
                        String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                        MazeGrid loaded = mzLoader.loadFromFile(filePath);

                        if (loaded == null) {
                            JOptionPane.showMessageDialog(null, "INVALID FILE", "ERROR", JOptionPane.WARNING_MESSAGE);
                            System.out.println("INVALID FILE");
                        } else {
                            mzGrid = loaded;
                            mainMenu.enableStartButton();
                        }
                    }
                    break;
                case "EXIT":
                    System.out.println("EXIT");
                    System.exit(0);
                default:
                    break;
            }
        }

    }

    class MazeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            switch (e.getActionCommand()) {
                case "BFS":
                    MazeSolver solver = new MazeSolver(mzGrid);
                    CustomStack<Position> path = solver.solve();
                    SimulationMetrics metrics = solver.getMetrics();

                    gui.showMaze(mzGrid);
                    mazeView.loadMap(mzGrid);
                    mazeView.repaint();

                    if (path.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No path found", "UNSOLVABLE MAZE",
                                JOptionPane.WARNING_MESSAGE);
                    } else {
                        Runnable showMetrics = () -> JOptionPane.showMessageDialog(null,
                                "Steps explored: " + metrics.getTotalSteps() +
                                        "\nPath length: " + metrics.getPathLength() +
                                        "\nExecution time: " + metrics.getExecutionTimeMs() + "ms");

                        java.util.ArrayList<Position> explored = solver.getExplorationOrder();
                        animateExploration(explorationToDirections(explored, solver), showMetrics);
                    }
                    break;
                case "PLAY":
                    MazeSolver solver2 = new MazeSolver(mzGrid);
                    CustomStack<Position> path2 = solver2.solve();
                    SimulationMetrics metrics2 = solver2.getMetrics();

                    gui.showMaze(mzGrid);
                    mazeView.loadMap(mzGrid);
                    mazeView.repaint();

                    if (path2.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No path found", "UNSOLVABLE MAZE",
                                JOptionPane.WARNING_MESSAGE);
                    } else {
                        Runnable showMetrics = () -> JOptionPane.showMessageDialog(null,
                                "Steps explored: " + metrics2.getTotalSteps() +
                                        "\nPath length: " + metrics2.getPathLength() +
                                        "\nExecution time: " + metrics2.getExecutionTimeMs() + "ms");

                        animateExploration(pathToDirections(path2), showMetrics);
                    }
                    break;
                case "MENU":
                    System.out.println("MAIN MENU clicked");
                    if (animationTimer != null && animationTimer.isRunning()) {
                        animationTimer.stop();
                    }
                    gui.showMenu();
                    // Do something make button not transparent
                    break;
                default:
                    break;
            }
        }
    }

    // Converts BFS visit order into a continuous walk of single-tile moves,
    // using true BFS parent pointers so backtracking is always correct (no
    // guessing by adjacency, which breaks in open/looping mazes).
    private List<String> explorationToDirections(List<Position> cells, MazeSolver solver) {
        List<String> directions = new java.util.ArrayList<>();
        Position current = cells.get(0);

        for (int i = 1; i < cells.size(); i++) {
            Position target = cells.get(i);
            java.util.List<Position> targetChain = ancestorChain(target, solver);
            Position lca = findFirstAncestorInChain(current, targetChain, solver);

            while (!samePos(current, lca)) {
                Position parent = solver.getParent(current);
                directions.add(directionBetween(current, parent));
                current = parent;
            }

            int startIndex = targetChain.indexOf(lca) - 1;
            for (int j = startIndex; j >= 0; j--) {
                Position step = targetChain.get(j);
                directions.add(directionBetween(current, step));
                current = step;
            }
        }

        return directions;
    }

    // Builds the chain [pos, parent(pos), grandparent(pos), ..., start].
    private List<Position> ancestorChain(Position pos, MazeSolver solver) {
        java.util.List<Position> chain = new java.util.ArrayList<>();
        Position node = pos;

        while (node != null) {
            chain.add(node);
            node = solver.getParent(node);
        }

        return chain;
    }

    // Walks 'from' upward via parent pointers until it lands on a cell that
    // also appears in 'chain' -- i.e. the lowest common ancestor.
    private Position findFirstAncestorInChain(Position from, java.util.List<Position> chain, MazeSolver solver) {
        Position node = from;

        while (!containsPos(chain, node)) {
            node = solver.getParent(node);
        }

        return node;
    }

    private boolean containsPos(java.util.List<Position> list, Position pos) {
        boolean found = false;
        for (Position p : list) {
            if (samePos(p, pos)) {
                found = true;
            }
        }
        return found;
    }

    private boolean samePos(Position a, Position b) {
        return a.row == b.row && a.col == b.col;
    }

    private String directionBetween(Position from, Position to) {
        int rowDiff = to.row - from.row;
        int colDiff = to.col - from.col;
        String direction = "";

        if (rowDiff == -1 && colDiff == 0)
            direction = "UP";
        else if (rowDiff == 1 && colDiff == 0)
            direction = "DOWN";
        else if (rowDiff == 0 && colDiff == -1)
            direction = "LEFT";
        else if (rowDiff == 0 && colDiff == 1)
            direction = "RIGHT";

        return direction;
    }

    // Walks the character one tile at a time along the full backtracking route.
    private void animateExploration(List<String> directions, Runnable onFinished) {
        if (animationTimer != null && animationTimer.isRunning()) {
            animationTimer.stop();
        }

        animationTimer = new javax.swing.Timer(100, null);
        final int[] index = { 0 };

        animationTimer.addActionListener(e -> {
            if (index[0] < directions.size()) {
                mazeView.moveCharacter(directions.get(index[0]));
                index[0]++;
            } else {
                animationTimer.stop();
                if (onFinished != null) {
                    onFinished.run();
                }
            }
        });

        animationTimer.start();
    }

    // Converts the shortest path (popped start->goal from solve()'s CustomStack)
    // into cardinal directions. Every consecutive pair is guaranteed adjacent
    // since buildPath() walks strict parent-to-child, so no backtracking logic
    // is needed here.
    private List<String> pathToDirections(CustomStack<Position> path) {
        java.util.List<Position> positions = new java.util.ArrayList<>();
        while (!path.isEmpty()) {
            positions.add(path.pop());
        }

        java.util.List<String> directions = new java.util.ArrayList<>();
        for (int i = 1; i < positions.size(); i++) {
            directions.add(directionBetween(positions.get(i - 1), positions.get(i)));
        }
        return directions;
    }
}
